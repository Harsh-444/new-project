namespace Repository.ViewModel;

public class MenuItemViewModel
{
    public List<CategoryViewModel> Categories { get; set; } = new List<CategoryViewModel>();
    public List<ItemViewModel> Items { get; set; } = new List<ItemViewModel>();
}
