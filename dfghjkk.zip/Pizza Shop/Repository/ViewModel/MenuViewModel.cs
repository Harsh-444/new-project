namespace Repository.ViewModel;

public class MenuViewModel
{

    
}
