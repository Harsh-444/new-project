namespace Repository.ViewModel;

public class RolesViewModel
{
    public int RoleId { get; set; }

    public string? RoleName { get; set; }
}
