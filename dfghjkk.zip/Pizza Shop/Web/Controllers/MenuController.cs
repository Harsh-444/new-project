using Microsoft.AspNetCore.Mvc;
using Service.Interfaces;
using Repository;
using Repository.Data;
using Repository.ViewModel;
using Microsoft.EntityFrameworkCore;
using Repository.Models;

namespace Web.Controllers;

public class MenuController : Controller
{
    private readonly IAuthService _authService;
    private readonly IUserService _userService;
    private readonly ApplicationDbContext _db;

    public MenuController(IAuthService authService, IUserService userService, ApplicationDbContext db)
    {
        _authService = authService;
        _userService = userService;
        _db = db;
    }
    [HttpGet("Menu")]
    public async Task<IActionResult> Menu(int categoryid = 1)
    {
        var categories = await _db.Menucategories
            .Where(c => c.Isdeleted == false)
            .Select(c => new CategoryViewModel
            {
                Categoryid = c.Menucategoryid,
                Name = c.Categoryname,
                Description = c.Description
            })
            .ToListAsync();

        var items = await _db.Items
            .Where(c => c.Isdeleted == false && c.Ismodifiable == false && c.Categoryid == categoryid)
            .Select(i => new ItemViewModel
            {
                Itemid = i.Itemid,
                Name = i.Itemname,
                Rate = i.Rate ?? 0,
                Quantity = i.Quantity,
                Itemtype = i.Itemtype,
                Isavailable = i.Available,
                // Itemimage = i.Itemimage ?? "~/images/dinning-menu.png"
            })
            .ToListAsync();

        var viewmodel = new MenuItemViewModel
        {
            Categories = categories,
            Items = items
        };

        return View(viewmodel);
    }

    [HttpGet("GetItemsByCategory")]
    public IActionResult GetItemsByCategory(int categoryid = 1)
    {
        var items = _db.Items
                        .Where(c => c.Categoryid == categoryid && c.Isdeleted == false && c.Ismodifiable == false)
                        .ToList();

        var itemViewModels = items.Select(item => new ItemViewModel
        {
            Itemid = item.Itemid,
            Name = item.Itemname,
            Itemtype = item.Itemtype,
            Rate = item.Rate ?? 0,
            Quantity = item.Quantity,
            Itemimage = item.Itemimage,
            Isavailable = item.Available
        }).ToList();

        return PartialView("_MenuItems", itemViewModels);
    }


    [HttpGet("AddCategory")]
    public IActionResult AddCategory()
    {
        return View();
    }

    [HttpPost("AddCategory")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AddCategory(CategoryViewModel model)
    {
        if (ModelState.IsValid)
        {
            try
            {
                var category = new Menucategory
                {
                    Menucategoryid = model.Categoryid,
                    Categoryname = model.Name,
                    Description = model.Description,
                    Isdeleted = false
                };
                await _db.Menucategories.AddAsync(category);
                await _db.SaveChangesAsync();
                TempData["success"] = "Category is Added!";
                return RedirectToAction("Menu");
            }
            catch (Exception ex)
            {
                TempData["error"] = "An error occurred while adding the category. Please try again.";
                return View(model);
            }
        }

        return View(model);
    }


    [HttpGet("EditCategory")]
    public IActionResult EditCategory(int id)
    {
        var category = _db.Menucategories.FirstOrDefault(c => c.Menucategoryid == id && c.Isdeleted == false);
        if (category == null)
        {
            return NotFound();
        }
        var categoryViewModel = new CategoryViewModel
        {
            Categoryid = category.Menucategoryid,
            Name = category.Categoryname,
            Description = category.Description
        };
        return View(categoryViewModel);
    }

    [HttpPost("EditCategory")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditCategory(CategoryViewModel model)
    {
        if (ModelState.IsValid)
        {
            try
            {
                var category = _db.Menucategories.FirstOrDefault(u => u.Menucategoryid == model.Categoryid);
                if (category == null)
                {
                    TempData["error"] = "Category not found.";
                    return RedirectToAction("Menu");
                }
                category.Categoryname = model.Name;
                category.Description = model.Description;
                _db.Menucategories.Update(category);
                await _db.SaveChangesAsync();
                TempData["success"] = "Category Edited Successfully!";
                return RedirectToAction("Menu");
            }
            catch (Exception ex)
            {
                TempData["error"] = "An error occurred while editing the category. Please try again.";
                return RedirectToAction("Menu");
            }
        }
        return View(model);
    }

    [HttpGet("DeleteCategory")]
    public IActionResult DeleteCategory(int categoryId)
    {
         var category = _db.Menucategories.FirstOrDefault(c => c.Menucategoryid == categoryId);
        if (category == null)
        {
            return NotFound();
        }
        category.Isdeleted = true;
        _db.SaveChanges();
        TempData["success"] = "Category is Deleted";
        return RedirectToAction("Menu");
    }

    [HttpPost("AddNewItem")]
    public async Task<IActionResult> AddNewItem(ItemViewModel model)
    {
        try
        {
            var menuItem = new Item
            {
                Categoryid = model.CategoryId,
                Itemname = model.Name,
                Itemtype = model.Itemtype,
                Rate = model.Rate,
                Quantity = model.Quantity,
                Unit = model.Unit,
                Available = model.Isavailable,
                Tax = model.Tax,
                Itemshortcode = model.ItemShortCode,
                Description = model.Description,
                // Itemimage = _userService.ImageUpload(model.ItemPhoto)
            };

            _db.Items.Add(menuItem);
            await _db.SaveChangesAsync();

            TempData["success"] = "Menu item added successfully!";
            return RedirectToAction("Menu");
        }
        catch (Exception ex)
        {
            TempData["error"] = "An error occurred while adding the item. Please try again.";
            return View(model);
        }
    }

    [HttpGet("EditMenuItem")]
    public IActionResult EditMenuItem(int id)
    {
        try
        {
            var item = _db.Items
                          .Where(m => m.Itemid == id)
                          .FirstOrDefault();

            if (item == null)
            {
                return NotFound();
            }

            var categories = _db.Menucategories
                                .Select(c => new CategoryViewModel
                                {
                                    Categoryid = c.Menucategoryid,
                                    Name = c.Categoryname
                                }).ToList();

            var viewModel = new MenuItemViewModel
            {
                Items = new List<ItemViewModel>
                {
                    new ItemViewModel
                    {
                        Itemid = item.Itemid,
                        Name = item.Itemname,
                        CategoryId = item.Categoryid,
                        Itemtype = item.Itemtype,
                        Rate = item.Rate,
                        Quantity = item.Quantity,
                        Unit = item.Unit,
                        Isavailable = item.Available,
                        Tax = item.Tax,
                        ItemShortCode = item.Itemshortcode,
                        Description = item.Description,
                        Itemimage = item.Itemimage
                    }
                },
                Categories = categories
            };
            return PartialView("_EditMenuItemModal", viewModel);
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Internal server error.");
        }
    }


    // POST: Edit Menu Item (update the item)
    [HttpPost("EditMenuItem")]
    public IActionResult EditMenuItem(int id, MenuItemViewModel model)
    {
        try
        {
            // if (!ModelState.IsValid)
            // {
            //     return BadRequest(ModelState);
            // }
            var item = _db.Items
                          .Where(m => m.Itemid == id)
                          .FirstOrDefault();
            if (item == null)
            {
                return NotFound();
            }
            item.Itemname = model.Items.FirstOrDefault()?.Name;
            item.Categoryid = model.Items.FirstOrDefault()?.CategoryId ?? item.Categoryid;
            item.Itemtype = (bool)(model.Items.FirstOrDefault()?.Itemtype);
            item.Rate = model.Items.FirstOrDefault()?.Rate ?? item.Rate;
            item.Quantity = model.Items.FirstOrDefault()?.Quantity ?? item.Quantity;
            item.Unit = model.Items.FirstOrDefault()?.Unit;
            item.Available = model.Items.FirstOrDefault()?.Isavailable ?? item.Available;
            item.Tax = model.Items.FirstOrDefault()?.Tax ?? item.Tax;
            item.Itemshortcode = model.Items.FirstOrDefault()?.ItemShortCode;
            item.Description = model.Items.FirstOrDefault()?.Description;
            item.Itemimage = model.Items.FirstOrDefault()?.Itemimage;

            _db.Items.Update(item);
            _db.SaveChanges();

            return Json(new { success = true, message = "Item updated successfully." });
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Internal server error.");
        }
    }
}
